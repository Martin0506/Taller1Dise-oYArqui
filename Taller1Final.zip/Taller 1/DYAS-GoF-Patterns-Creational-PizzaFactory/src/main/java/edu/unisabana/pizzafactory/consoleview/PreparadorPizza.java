package edu.unisabana.pizzafactory.consoleview;

import edu.unisabana.pizzafactory.model.*;
import javax.swing.JOptionPane;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import edu.unisabana.pizzafactory.model.TipoPizza;


public class PreparadorPizza {

    public static void main(String args[]) {
        String input = JOptionPane.showInputDialog("Ingrese su pedido:\n1. Pizza Delgada \n2. Pizza Gruesa \n3. Pizza Integral\n4. Salir");
        // Convertir la entrada a un número entero
        int pedido = Integer.parseInt(input);
        PreparadorPizza preparadorPizza = new PreparadorPizza();

        switch (pedido) {
            case 1:
                preparadorPizza.prepararPizza(TipoPizza.DELGADA);
                break;
            case 2:
                preparadorPizza.prepararPizza(TipoPizza.GRUESA);
                break;
            case 3:
                preparadorPizza.prepararPizza(TipoPizza.INTEGRAL);
                break;
            case 4:
                JOptionPane.showMessageDialog(null, "Saliendo...");
                break;
            default:
                JOptionPane.showMessageDialog(null, "Opción no válida");
        }
    }

    private void prepararPizza(TipoPizza tipo) {
        try {
            Ingrediente[] ingredientes = obtenerIngredientes(tipo);
            Tamano tamano = Tamano.PEQUENO; // Puedes modificar esto según el requerimiento

            FabricaPizza fabrica = crearFabrica(tipo);
            Amasador am = fabrica.crearAmasador();
            Horneador hpd = fabrica.crearHorneador();
            Moldeador mp = fabrica.crearMoldeador();

            am.amasar();
            moldearPizza(mp, tamano);
            aplicarIngredientes(ingredientes);
            hpd.hornear();

        } catch (ExcepcionParametrosInvalidos ex) {
            Logger.getLogger(PreparadorPizza.class.getName()).log(Level.SEVERE, "Problema en la preparación de la Pizza", ex);
        }
    }

    private FabricaPizza crearFabrica(TipoPizza tipo) {
        switch (tipo) {
            case DELGADA:
                return new FabricaPizzaDelgada() {};
            case GRUESA:
                return new FabricaPizzaGruesa() {};
            case INTEGRAL:
                return new FabricaPizzaIntegral() {};
            default:
                throw new IllegalArgumentException("Tipo de pizza no válido: " + tipo);
        }
    }

    private Ingrediente[] obtenerIngredientes(TipoPizza tipo) {
        switch (tipo) {
            case DELGADA:
                return new Ingrediente[]{new Ingrediente("queso", 1), new Ingrediente("jamón", 2)};
            case GRUESA:
                return new Ingrediente[]{new Ingrediente("cebolla", 1), new Ingrediente("jamón", 2)};
            case INTEGRAL:
                return new Ingrediente[]{new Ingrediente("tomate", 1), new Ingrediente("albahaca", 2)};
            default:
                return new Ingrediente[0]; // En caso de un tipo no válido
        }
    }

    private void moldearPizza(Moldeador mp, Tamano tam) throws ExcepcionParametrosInvalidos {
        if (tam == Tamano.PEQUENO) {
            mp.moldearPizzaPequena();
        } else if (tam == Tamano.MEDIANO) {
            mp.molderarPizzaMediana();
        } else {
            throw new ExcepcionParametrosInvalidos("Tamaño de pizza inválido: " + tam);
        }
    }

    private void aplicarIngredientes(Ingrediente[] ingredientes) {
        Logger.getLogger(PreparadorPizza.class.getName())
                .log(Level.INFO, "APLICANDO INGREDIENTES: {0}", Arrays.toString(ingredientes));
        
        // Código de llamado al microcontrolador
    }
}
