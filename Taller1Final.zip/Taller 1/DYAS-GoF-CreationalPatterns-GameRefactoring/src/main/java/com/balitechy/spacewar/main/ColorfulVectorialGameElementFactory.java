/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.balitechy.spacewar.main;

import java.io.IOException;

/**
 *
 * @author martin-jerez
 */
public class ColorfulVectorialGameElementFactory implements IFactory{
      @Override
    public IBullet createBullet(double x, double y, Game game) {
        return new Bullet(x, y, game); // Para sprites
    }

    @Override
    public IBackgroundRenderer createBackgroundRenderer(String type) throws IOException {
        if (type.equalsIgnoreCase("sprite")) {
            return new BackgroundRenderer("/bg.png"); // Esta línea puede lanzar IOException
        } else if (type.equalsIgnoreCase("vector")) {
            
            return new BackgroundRendererVector(); 
        }
        throw new IllegalArgumentException("Tipo de fondo no soportado: " + type);
    }

    @Override
    public IPlayer createPlayer(double x, double y, Game game) {
        return new Player(x, y, game); // Para el jugador
    }
}
