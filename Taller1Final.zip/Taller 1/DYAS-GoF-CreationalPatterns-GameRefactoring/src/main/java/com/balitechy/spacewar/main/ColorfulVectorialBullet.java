/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.balitechy.spacewar.main;
import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author martin-jerez
 */
public class ColorfulVectorialBullet implements IBullet{
    private double x;
    private double y;
    public static final int WIDTH = 11;
    public static final int HEIGHT = 21;

    public ColorfulVectorialBullet(double x, double y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public void tick() {
        y -= 5; // Mueve la bala hacia arriba
    }

    @Override
    public void render(Graphics g) {
        // Dibuja un rectángulo como representación vectorial de la bala
        g.setColor(Color.RED);
        g.fillRect((int) x, (int) y, WIDTH, HEIGHT);
    }

    @Override
    public double getY() {
        return y; // Devuelve la posición Y actual de la bala
    }
}
