package com.balitechy.spacewar.main;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.image.BufferStrategy;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JFrame;

public class Game extends Canvas implements Runnable {

    private static final long serialVersionUID = 1L;
    public static final int WIDTH = 320;
    public static final int HEIGHT = WIDTH / 12 * 9;
    public static final int SCALE = 2;
    public final String TITLE = "Space War 2D";

    private boolean running = false;
    private Thread thread;

    private SpritesImageLoader sprites;
    private Player player;
    private BulletController bullets;
    private IBackgroundRenderer backgRenderer;
    private IFactory factory;
   public Game(IFactory factory) {
    // Inicializar componentes
    this.factory = factory; // Almacenar la fábrica pasada al constructor
    
}

    public void init(String backgroundType) {
    requestFocus();
    
    sprites = new SpritesImageLoader("/sprites.png");
    try {			
        sprites.loadImage();
    } catch (IOException e) {
        e.printStackTrace();
    }
    
    addKeyListener(new InputHandler(this));

    

    // Crea el fondo basado en el tipo especificado
    try {
        backgRenderer = factory.createBackgroundRenderer(backgroundType);
    } catch (IOException e) {
        e.printStackTrace();
    }

    player = new Player((WIDTH * SCALE - Player.WIDTH) / 2, HEIGHT * SCALE - 50 , this);
    bullets = new BulletController();
}


    public SpritesImageLoader getSprites() {
        return sprites;
    }

    public BulletController getBullets() {
        return bullets;
    }

    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();

        switch (key) {
            case KeyEvent.VK_RIGHT:
                player.setVelX(5);
                break;
            case KeyEvent.VK_LEFT:
                player.setVelX(-5);
                break;
            case KeyEvent.VK_UP:
                player.setVelY(-5);
                break;
            case KeyEvent.VK_DOWN:
                player.setVelY(5);
                break;
            case KeyEvent.VK_SPACE:
                player.shoot();
                break;
        }
    }

    public void keyReleased(KeyEvent e) {
        int key = e.getKeyCode();

        switch (key) {
            case KeyEvent.VK_RIGHT:
            case KeyEvent.VK_LEFT:
                player.setVelX(0);
                break;
            case KeyEvent.VK_UP:
            case KeyEvent.VK_DOWN:
                player.setVelY(0);
                break;
        }
    }

    private synchronized void start() {
        if (running) return;

        running = true;
        thread = new Thread(this);
        thread.start();
    }

    private synchronized void stop() {
        if (!running) return;

        running = false;
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.exit(1);
    }

    @Override
    public void run() {
        init("vector");

        long lastTime = System.nanoTime();
        final double numOfTicks = 60.0;
        double ns = 1000000000 / numOfTicks;
        double delta = 0;
        int updates = 0;
        int frames = 0;
        long timer = System.currentTimeMillis();

        while (running) {
            long now = System.nanoTime();
            delta += (now - lastTime) / ns;
            lastTime = now;
            if (delta >= 1) {
                tick();
                updates++;
                delta--;
            }
            try {
                render();
            } catch (IOException ex) {
                Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
            }
            frames++;

            if (System.currentTimeMillis() - timer > 1000) {
                timer += 1000;
                System.out.println(updates + " ticks, fps " + frames);
                updates = 0;
                frames = 0;
            }
        }
        stop();
    }

    public void tick() {
        player.tick();
        bullets.tick();
    }

    public void render() throws IOException {
    BufferStrategy bs = this.getBufferStrategy();
    if (bs == null) {
        createBufferStrategy(3);
        return; // Regresa si no hay BufferStrategy disponible
    }

    Graphics g = bs.getDrawGraphics();
    // Renderizar el fondo, el jugador y las balas
    if (backgRenderer != null) {
        backgRenderer.render(g, this);
    }
    if (player != null) {
        player.render(g);
    }
    if (bullets != null) {
        bullets.render(g);
    }
    
    g.dispose(); // Asegúrate de liberar el gráfico
    bs.show();   // Muestra el buffer en pantalla
}



    public static void main(String args[]) {
        IFactory factory;
         // Selección de la fábrica basada en alguna condición o argumento
        if (args.length > 0 && "colorful-vectorial".equals(args[0])) {
            factory = new ColorfulVectorialGameElementFactory();
        } else {
            factory = new GameFactory(); // Fábrica por defecto
        }

        Game game = new Game(factory);
        game.setPreferredSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));
        game.setMaximumSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));
        game.setMinimumSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));

        JFrame frame = new JFrame(game.TITLE);
        frame.add(game);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        game.start();
    }
}
