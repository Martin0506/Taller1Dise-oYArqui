/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.balitechy.spacewar.main;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.io.IOException;
/**
 *
 * @author martin-jerez
 */
public class ColorfulVectorialBackgroundRenderer implements IBackgroundRenderer{
    @Override
    public void render(Graphics g, Canvas c) throws IOException{
        // Por ejemplo, un fondo de degradado o colores sólidos
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, c.getWidth(), c.getHeight());
        
        // Se pueden agregar otros elementos vectoriales aquí
        g.setColor(Color.DARK_GRAY);
        g.fillOval(50, 50, 200, 200);  // Ejemplo de un círculo en el fondo
    }
}
