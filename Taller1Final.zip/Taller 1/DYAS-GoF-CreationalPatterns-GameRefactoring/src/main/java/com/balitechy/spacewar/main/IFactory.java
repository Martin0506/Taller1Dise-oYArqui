/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.balitechy.spacewar.main;
import java.io.IOException;

/**
 *
 * @author Luisa Carpintero
 */
public interface IFactory {
    IBullet createBullet(double x, double y, Game game);
    IBackgroundRenderer createBackgroundRenderer(String type) throws IOException;
    IPlayer createPlayer(double x, double y, Game game);
}
