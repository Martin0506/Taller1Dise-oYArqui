/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.balitechy.spacewar.main;

/**
 *
 * @author Luisa Carpintero
 */
import java.awt.Color;
import java.awt.Graphics;

public class PlayerVector implements IPlayer {

    private double x;
    private double y;
    private double velX;
    private double velY;
    
    public static final int WIDTH = 56;
    public static final int HEIGHT = 28;
    
    public PlayerVector(double x, double y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public double getX() {
        return x;
    }

    @Override
    public void setX(double x) {
        this.x = x;
    }

    @Override
    public double getY() {
        return y;
    }

    @Override
    public void setY(double y) {
        this.y = y;
    }

    @Override
    public void setVelX(double velX) {
        this.velX = velX;
    }

    @Override
    public void setVelY(double velY) {
        this.velY = velY;
    }

    @Override
    public void shoot() {
        // Aquí podrías implementar el disparo usando BulletVector
    }

    @Override
    public void tick() {
        x += velX;
        y += velY;

        if (x <= 0)
            x = 0;
        if (x >= (Game.WIDTH * Game.SCALE) - WIDTH)
            x = (Game.WIDTH * Game.SCALE) - WIDTH;
        if (y <= 0)
            y = 0;
        if (y >= (Game.HEIGHT * Game.SCALE) - HEIGHT)
            y = (Game.HEIGHT * Game.SCALE) - HEIGHT;
    }

    @Override
    public void render(Graphics g) {
        g.setColor(Color.BLUE);
        g.fillRect((int) x, (int) y, WIDTH, HEIGHT);
    }
}
