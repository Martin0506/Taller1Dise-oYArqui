/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.balitechy.spacewar.main;

import java.awt.Graphics;

/**
 *
 * @author Luisa Carpintero
 */
public interface IPlayer {
    double getX();
    double getY();
    void setX(double x);
    void setY(double y);
    void setVelX(double velX);
    void setVelY(double velY);
    void shoot();
    void tick();
    void render(Graphics g);
}
